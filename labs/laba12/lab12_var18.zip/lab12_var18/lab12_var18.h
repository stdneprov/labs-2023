#include <math.h>
#include <stdio.h>
#include <stdlib.h>

int amount_of_digits(int n);
int change_2nd_and_prelast(int n);